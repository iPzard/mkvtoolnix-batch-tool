mxe_dir=${mxe_dir:-${HOME}/prog/video/mingw/cross}
saxon_dir=${saxon_dir:-${HOME}/opt/saxon-he}
file_list_dir=${file_list_dir:-${HOME}/prog/video/mingw/src/uc/file-lists}

export mxe_dir saxon_dir file_list_dir
